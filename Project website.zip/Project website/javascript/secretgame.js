let tree;
let box;
let boxX = 100;
let boxY = 425;
let apples = [];
let score = 0;
let streak = 0;
let lives = 5;
let livesX = 1075;
let backLink = document.getElementById("back");
function setup(){
  createCanvas(1280,600)
  tree = loadImage('../fotos/tree.png');
  box = loadImage('../fotos/box.png')
  apple = loadImage('../fotos/apple.png')
  heart = loadImage('../fotos/heart.png')
  let file = fopen("highscore.txt", 0);
  let highscore = fread(file, 1);
  console.log(highscore);
}
function draw(){
  fill(0,100,255);
  rect(0,0,1280,720);
  fill(0,255,0);
  rect(0,500,1280,100);
  image(tree, 850,260, 300, 300)
  image(box, boxX,boxY,100,100);
  fill(0,0,0);
  textSize(32);
  text("Score: " + score.toString(), 25,50);
  text("Streak: " + streak.toString(), 25,100);
  if (keyIsDown(RIGHT_ARROW)){
    boxX += 16 * deltaTime;
  }
  if (keyIsDown(LEFT_ARROW)){
    boxX -= 10;
  }
  for (i = 0; i < apples.length; i++){
    element = apples[i];
    element.update();
    if (element.checkCollision()){
      apples.splice(i,1);
      score += 1;
      streak += 1;
    }
  }
  for (i = 0; i < lives; i++){
    image(heart,livesX+(40*i),10,25,25)
  }
}
class Apple{
  constructor(x,y){
    this.x = x;
    this.y = y;
  }
  update(){
    this.y += 2;
    image(apple, this.x, this.y, 35, 35);
  }
  checkCollision(){
    if (this.x > boxX && this.x+35 < boxX+100){
      if (this.y > boxY && this.y+35<boxY+100){
        return true;
      }
    }
    if (this.y+35 > 500){
      streak = -1;
      lives -= 1;
      livesX += 40
      return true;
    }
    if (lives == 0){
      noLoop();
      fill(0,100,255);
      rect(0,0,1280,720);
      fill(0,255,0);
      rect(0,500,1280,100);
      fill(0,0,0)
      textSize(100)
      text("Game Over!", 400, 600/2);
    }
    if (score > 9){
      document.getElementById("back").innerHTML = "Terug";
    }
  }
}
let appleX = 0;
let temp = 0;
setTimeout(dropApple(), 1000);
function dropApple(){
  appleX = Math.random()*1280;
  if (appleX > temp){
    if (appleX - temp > 600){
      appleX = temp+600;
    }
  } else if (appleX < temp){
    if (temp - appleX > 600){
      appleX = temp-600;
    }
  }
  apples.push(new Apple(appleX,0))
  temp = appleX;
  setTimeout(dropApple, 1000);
}
