let backgroundcolor = (0,0,0);
let doos;
let uitlegText = document.getElementById("uitleg");
let op = 0;
let clicked = false;
function setup() {
  let canvas = createCanvas(800,600);
  canvas.parent('canvas');
  doos = loadImage('../fotos/doos/doos1.jpg');
}
function draw(){
  fill(backgroundcolor);
  rect(0,0,1280,720);
  fill(255,255,255)
  rect(mouseX,mouseY,20,20)
  image(doos,0,0, 800,600);
  text(mouseX.toString() + ", " + mouseY.toString(), 0,100)
  uitlegText.style.opacity = op;
  if (clicked){
    op += 0.025;
  }
}
function mousePressed(){
  if (mouseX > 250 && mouseX < 280){
    console.log("X");
    if (mouseY > 180 && mouseY < 380){
      clicked = true;
      uitlegText.innerHTML = "Dit is de led strip. Deze kan je van kleur veranderen met de kleine knop.";
    }
  }
  if (mouseX > 165 && mouseX < 315){
    if (mouseY > 410 && mouseY < 530){
      clicked = true;
      uitlegText.innerHTML = "Dit is het bed."
    }
  }
  if (mouseX > 380 && mouseX < 460){
    if (mouseY > 325 && mouseY < 480){
      clicked = true;
      uitlegText.innerHTML = "Dit is de kast."
    }
  }
  if (mouseX > 430 && mouseX < 450){
    if (mouseY > 100 && mouseY < 155){
      clicked = true;
      uitlegText.innerHTML = "Dit is het blauwe lampje. Dit lampje gaat aan/uit als je klapt."
    }
  }
  if (mouseX > 515 && mouseX < 625){
    if (mouseY > 400 && mouseY < 500){
      if (mouseX > 575 && mouseX < 595){
        if (mouseY > 434 && mouseY < 445){
          clicked = true;
          uitlegText.innerHTML = "Dit is het gele lampje. Dit lampje gaat aan/uit als je klapt."
        }
      } else {
        clicked = true;
        uitlegText.innerHTML = "Dit is de bewoner van het huis. Zeg hallo."
      }
    }
  }
  if (mouseX > 700 && mouseX < 745){
    if (mouseY > 470 && mouseY < 525){
      clicked = true;
      uitlegText.innerHTML = "Dit is het kleine knopje. Dit knopje kan de led strip aan en uit doen,<br> en de led strip van kleur laten veranderen."
    }
  }
  if (mouseX > 0 && mouseX < 75){
    if (mouseY > 250 && mouseY < 340){
      clicked = true;
      uitlegText.innerHTML = "Dit is de deurbel. Als je de knop indrukt dan speelt er een geluidje af."
    }
  }
  if (mouseX > 550 && mouseX < 790){
    if (mouseY > 10 && mouseY < 40){
      clicked = true;
      uitlegText.innerHTML = "Dit zijn de zonnepanelen. Deze doen ni- ik bedoel deze geven het huis stroom.";
    }
  }
}
